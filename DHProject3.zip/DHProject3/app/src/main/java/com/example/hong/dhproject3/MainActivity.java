package com.example.hong.dhproject3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
        EditText et1,et2;
        Button bt1;
        TextView tv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1 = (EditText)findViewById(R.id.idInput);
        et2 = (EditText)findViewById(R.id.pwInput);
        bt1 = (Button)findViewById(R.id.logIn);
        tv1 = (TextView)findViewById(R.id.signUp);
        tv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),signUp.class);
                startActivity(intent);
            }
        });
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id = et1.getText().toString();
                String pw = et2.getText().toString();
                String token =  FirebaseInstanceId.getInstance().getToken();
                loginInfo(id,pw, token);
                /*Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
                startActivity(intent);*/
            }
        });
    }
    public void loginInfo(String a, String b, String c){
        OkHttpClient client = new OkHttpClient();
        RequestBody formBody = new FormBody.Builder().add("email", a).add("password", b).add("user_token", c).build();
        Request request = new Request.Builder().url("https://button-hanyoon1108.c9users.io/login_request").post(formBody).build();

        client.newCall(request).enqueue(loginInfoCallback);
    }
    private Callback loginInfoCallback = new Callback(){
        @Override
        public void onFailure(Call call, IOException e){
            Log.d("TEST", "ERROR MESSAGE : " + e.getMessage());
        }

        @Override
        public void onResponse(Call call, Response response) throws IOException {
            final String responseData = response.body().string();
            try{
                JSONObject jo = new JSONObject(responseData);
                String status = jo.getString("status");
                if(status.equals("Good")){
                    Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
                startActivity(intent);}
                else{
                    Log.d("Result: ", status);
                    Log.d("Result: ", "잘못 입력함");}
                Log.d("Test" , jo.getString("status"));
            } catch(JSONException e){}
            Log.d("TEST", "Data :" );
            /*if(responseData.equals("0")){
                Toast.makeText(getApplicationContext(), "존재하지 않는 이메일 주소 입니다.",Toast.LENGTH_LONG).show();
                clear();
               }
            else if(responseData.equals("1")){
                Toast.makeText(getApplicationContext(), "이메일과 비밀번호가 일치하지 않습니다", Toast.LENGTH_LONG).show();
            clear();
            }
            else if(responseData.equals("2")) {
                Toast.makeText(getApplicationContext(), "로그인 되셨습니다", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
                startActivity(intent);
            }*/
        }
    };
    public void clear(){
        et1.setText("");
        et2.setText("");
    }
}
