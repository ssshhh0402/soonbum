package com.example.hong.dhproject3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class signUp extends AppCompatActivity {
        EditText et1, et2;
        Button bt1, bt2;
        String id, pw;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        et1 = (EditText) findViewById(R.id.etId);
        et2 = (EditText) findViewById(R.id.etPw);
        bt1 = (Button) findViewById(R.id.register);
        bt2 = (Button) findViewById(R.id.cancel);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                id = et1.getText().toString();
                pw = et2.getText().toString();
                String token =  FirebaseInstanceId.getInstance().getToken();
                signUpInfo(id,pw,token);
                Toast.makeText(getApplicationContext(), "성공적으로 회원가입되셨습니다", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
    public void signUpInfo(String a, String b, String c){
        OkHttpClient client = new OkHttpClient();
        RequestBody formBody = new FormBody.Builder().add("email", a).add("password", b).add("user_token", c).build();
        Request request = new Request.Builder().url("https://button-hanyoon1108.c9users.io/user_create").post(formBody).build();

        client.newCall(request).enqueue(signUpInfoCallback);
    }
    private Callback signUpInfoCallback = new Callback(){
        @Override
                public void onFailure(Call call, IOException e){
            Log.d("TEST", "ERROR MESSAGE : " + e.getMessage());
        }

        @Override
                public void onResponse(Call call, Response response) throws IOException{
            final Long responseData = response.body().contentLength();
            Log.d("TEST", "responseDatae : " + responseData);
        }
    };
}
